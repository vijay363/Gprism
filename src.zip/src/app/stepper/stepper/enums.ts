export enum Step {
  Step1 = 1,
  Step2,
  Step3,
  Step4,
}
  
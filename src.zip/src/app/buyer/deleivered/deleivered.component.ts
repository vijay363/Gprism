import { Component } from '@angular/core';

@Component({
  selector: 'app-deleivered',
  standalone: true,
  imports: [],
  templateUrl: './deleivered.component.html',
  styleUrl: './deleivered.component.css'
})
export class DeleiveredComponent {

}

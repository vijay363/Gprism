import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-advance-to-pay',
  standalone: true,
  imports: [],
  templateUrl: './advance-to-pay.component.html',
  styleUrl: './advance-to-pay.component.css'
})
export class AdvanceToPayComponent {
  constructor(private router: Router) {}
  navigateToMilestone(){
    this.router.navigate(['/buyer/milestones'])
  }
}

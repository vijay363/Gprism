import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-milestones',
  standalone: true,
  imports: [],
  templateUrl: './milestones.component.html',
  styleUrl: './milestones.component.css'
})
export class MilestonesComponent {
  constructor(private router:Router){}
  navigateToShipment(){
    this.router.navigate(['/buyer/shipment'])
  }
}

import { Component } from '@angular/core';

@Component({
  selector: 'app-orderclosed',
  standalone: true,
  imports: [],
  templateUrl: './orderclosed.component.html',
  styleUrl: './orderclosed.component.css'
})
export class OrderclosedComponent {

}

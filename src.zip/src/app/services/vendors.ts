export interface Vendors {
    company: string;
  }
  